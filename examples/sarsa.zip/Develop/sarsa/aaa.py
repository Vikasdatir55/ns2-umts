#!/usr/bin/python

from test_class import *

a = ob()
a.setId(0)
a.printV()
