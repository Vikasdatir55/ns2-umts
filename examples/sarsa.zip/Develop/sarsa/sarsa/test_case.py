#!/usr/bin/python

from element import *

agent = Agent()
agent.N = 10

agent._init_()
agent.episode()

print "Done"


