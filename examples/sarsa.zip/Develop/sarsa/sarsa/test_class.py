#!/usr/bin/python

class ob:
	def setName(self, name):
		self.name = name
	def setId(self, val):
		self.id = val
	def printV(self):
		val = self.id + 1
		print val